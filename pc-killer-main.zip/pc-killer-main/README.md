# PCkiller

<p align="center">
<a href="#"><img title="PC killer" src="https://s16.picofile.com/file/8417317400/new_pckiller.PNG"></img></a>
</p>
<br>

## What can it do?
#### Date: 11/18/2020
- Make 7 virus.
- Have a complity help list.
- It can make a hibrid virus.
- A simpel cmd: `PCkiller:\Home\`
<br>

## Installation
#### Instalation ONE:
- `Install GIT` from here: [Git site](https://git-scm.com/)
- `install python and library or tool do that!`
- open your cmd: `git clone https://github.com/sina-yeganeh/PCkiller/`
- `cd PCkiller` and `python main.py`
- **FINISH!**

#### Instalation TOW:
- Upload file
- open cmd and: `cd "path-file"`
- `python main.py`
- **FINISH!**
<br>

## Upgrade
#### What other options will be added?
- [ ] Add another Virus.
- [ ] Complet **My virus** part.
- [ ] Complet **File option** part.
- [ ] Add your affer!
<br>

- <p><b> Please comment and complete the bugs and sections. Thankful!</b></p>
